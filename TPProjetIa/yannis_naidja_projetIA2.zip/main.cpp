#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include "filereader.h"
#include "ouvert.h"
#include "ouvert_pile.h"
#include "etat.h"
#include "ferme.h"

using namespace std;

int main(int argc,char *argv[]){

    // appeller le programme avec comme argument le nom du fichier 

    if(argc<1)
        cout << "Entrez un nom de grille" << endl;

    string nom_fic=argv[1];
    
    filereader filer;
    etat *ei = new etat();
    etat *ef = new etat();
    
     filer.remplir_etat_initial(nom_fic,ei);
    
     filer.remplir_etat_final(nom_fic,ef);

    cout << "l'etat initial est " << endl;
    ei->affiche_etat();
    cout<< " l'etat final est " << endl;
    ef->affiche_etat();

    ferme myferme;

    ouvert *ouvert = new ouvert_pile();
    

    ouvert->parcours(ouvert,myferme,ei,ef);

    cout << "parcours fini " << endl;

    
}