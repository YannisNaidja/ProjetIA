#ifndef DEF_CASEVIDE
#define DEF_CASEVIDE

 struct casevide{
    int case_vide_x;
    int case_vide_y;
    const char *value = "";
}casevide;


#endif
